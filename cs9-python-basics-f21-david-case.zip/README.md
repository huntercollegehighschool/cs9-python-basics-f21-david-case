# PythonBasicsAssignment
The assignment are on pages part1.py, part2.py, part3.py, part4.py, and part5.py. Don't edit anything else. Click run on the top of the page to run any code. When you're done writing your code, click on the Version control tab (2nd tab on left of screen), enter a comment on what changed, and click Commit and push.
