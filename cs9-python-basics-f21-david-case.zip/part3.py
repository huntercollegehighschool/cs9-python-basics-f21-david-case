'''
______
PART 3
______
There are (at least) 6 errors in this code. Fix them so that it runs properly.

'''

#code starts here
number1 = int(input("Enter a number: "))
number2 = int(input("Enter another number: "))

print ("The sum of your numbers is", number1 + number2)
print ("Seven times your second number is", 7 * number2)
