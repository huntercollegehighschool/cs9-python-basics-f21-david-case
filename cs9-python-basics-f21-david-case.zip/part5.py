'''
______
PART 5
______
Write a program that prompts the user for two string inputs, a first name and a last name. The program will print the string "Hello, <firstname> <lastname>".

What should appear on the console when the program runs:

What is your first name? Ash
What is your last name? Ketchum
Hello, Ash Ketchum

'''

#start writing your code below
first_name = input("What is your first name? ")
last_name = input("What is your last name? ")

print("Hello,", first_name, last_name)